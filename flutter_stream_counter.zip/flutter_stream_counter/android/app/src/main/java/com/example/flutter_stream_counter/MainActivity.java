package com.example.flutter_stream_counter;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
